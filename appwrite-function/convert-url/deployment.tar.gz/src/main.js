/**
 * Appwrite Function: Convert URL to Markdown
 * 
 * This function fetches a webpage and converts it to:
 * - HTML (original)
 * - Markdown (formatted)
 * - Plain Text (clean text)
 */

// HTML to Markdown conversion
function htmlToMarkdown(html) {
  // Basic HTML to Markdown conversion
  // In production, consider using a library like 'turndown'
  
  let markdown = html;
  
  // Headers
  markdown = markdown.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '\n# $1\n\n');
  markdown = markdown.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '\n## $1\n\n');
  markdown = markdown.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '\n### $1\n\n');
  markdown = markdown.replace(/<h4[^>]*>(.*?)<\/h4>/gi, '\n#### $1\n\n');
  markdown = markdown.replace(/<h5[^>]*>(.*?)<\/h5>/gi, '\n##### $1\n\n');
  markdown = markdown.replace(/<h6[^>]*>(.*?)<\/h6>/gi, '\n###### $1\n\n');
  
  // Bold and Italic
  markdown = markdown.replace(/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/gi, '**$2**');
  markdown = markdown.replace(/<(em|i)[^>]*>(.*?)<\/(em|i)>/gi, '*$2*');
  
  // Links
  markdown = markdown.replace(/<a[^>]*href=["']([^"']*)["'][^>]*>(.*?)<\/a>/gi, '[$2]($1)');
  
  // Images
  markdown = markdown.replace(/<img[^>]*src=["']([^"']*)["'][^>]*alt=["']([^"']*)["'][^>]*>/gi, '![$2]($1)');
  markdown = markdown.replace(/<img[^>]*src=["']([^"']*)["'][^>]*>/gi, '![]($1)');
  
  // Lists
  markdown = markdown.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n');
  markdown = markdown.replace(/<\/?(ul|ol)[^>]*>/gi, '\n');
  
  // Paragraphs and breaks
  markdown = markdown.replace(/<p[^>]*>(.*?)<\/p>/gi, '$1\n\n');
  markdown = markdown.replace(/<br[^>]*>/gi, '\n');
  markdown = markdown.replace(/<hr[^>]*>/gi, '\n---\n');
  
  // Code
  markdown = markdown.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
  markdown = markdown.replace(/<pre[^>]*>(.*?)<\/pre>/gi, '\n```\n$1\n```\n');
  
  // Blockquotes
  markdown = markdown.replace(/<blockquote[^>]*>(.*?)<\/blockquote>/gi, '\n> $1\n');
  
  // Remove scripts, styles, and other non-content tags
  markdown = markdown.replace(/<script[^>]*>.*?<\/script>/gis, '');
  markdown = markdown.replace(/<style[^>]*>.*?<\/style>/gis, '');
  markdown = markdown.replace(/<nav[^>]*>.*?<\/nav>/gis, '');
  markdown = markdown.replace(/<header[^>]*>.*?<\/header>/gis, '');
  markdown = markdown.replace(/<footer[^>]*>.*?<\/footer>/gis, '');
  
  // Remove remaining HTML tags
  markdown = markdown.replace(/<[^>]+>/g, '');
  
  // Clean up HTML entities
  markdown = markdown.replace(/&nbsp;/g, ' ');
  markdown = markdown.replace(/&lt;/g, '<');
  markdown = markdown.replace(/&gt;/g, '>');
  markdown = markdown.replace(/&amp;/g, '&');
  markdown = markdown.replace(/&quot;/g, '"');
  markdown = markdown.replace(/&#39;/g, "'");
  
  // Clean up extra whitespace
  markdown = markdown.replace(/\n{3,}/g, '\n\n');
  markdown = markdown.replace(/ {2,}/g, ' ');
  
  return markdown.trim();
}

// HTML to Plain Text conversion
function htmlToPlainText(html) {
  let text = html;
  
  // Remove scripts, styles, and other non-content tags
  text = text.replace(/<script[^>]*>.*?<\/script>/gis, '');
  text = text.replace(/<style[^>]*>.*?<\/style>/gis, '');
  text = text.replace(/<nav[^>]*>.*?<\/nav>/gis, '');
  text = text.replace(/<header[^>]*>.*?<\/header>/gis, '');
  text = text.replace(/<footer[^>]*>.*?<\/footer>/gis, '');
  
  // Add line breaks for block elements
  text = text.replace(/<\/(p|div|h[1-6]|li|blockquote)>/gi, '\n\n');
  text = text.replace(/<br[^>]*>/gi, '\n');
  text = text.replace(/<hr[^>]*>/gi, '\n---\n');
  
  // List items
  text = text.replace(/<li[^>]*>/gi, '\n• ');
  
  // Remove all remaining HTML tags
  text = text.replace(/<[^>]+>/g, '');
  
  // Clean up HTML entities
  text = text.replace(/&nbsp;/g, ' ');
  text = text.replace(/&lt;/g, '<');
  text = text.replace(/&gt;/g, '>');
  text = text.replace(/&amp;/g, '&');
  text = text.replace(/&quot;/g, '"');
  text = text.replace(/&#39;/g, "'");
  
  // Clean up extra whitespace
  text = text.replace(/\n{3,}/g, '\n\n');
  text = text.replace(/ {2,}/g, ' ');
  
  return text.trim();
}

// Main function handler
export default async ({ req, res, log, error }) => {
  try {
    // Parse the request body
    const payload = JSON.parse(req.body || '{}');
    const { url } = payload;
    
    // Validate URL
    if (!url) {
      return res.json({ 
        success: false,
        error: 'URL is required' 
      }, 400);
    }

    log(`Converting URL: ${url}`);

    // Fetch the webpage
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; MarkMdBot/1.0)',
      },
    });

    if (!response.ok) {
      error(`Failed to fetch URL: ${response.statusText}`);
      return res.json({ 
        success: false,
        error: `Failed to fetch URL: ${response.statusText}` 
      }, response.status);
    }

    // Get HTML content
    const html = await response.text();
    
    // Convert to different formats
    log('Converting to Markdown and Plain Text...');
    const markdown = htmlToMarkdown(html);
    const plainText = htmlToPlainText(html);

    log('Conversion successful!');

    // Return the results
    return res.json({
      success: true,
      html,
      markdown,
      plainText,
      url,
    }, 200);

  } catch (err) {
    error(`Error converting URL: ${err.message}`);
    return res.json({ 
      success: false,
      error: err.message || 'Failed to convert URL',
      details: err.stack
    }, 500);
  }
};
